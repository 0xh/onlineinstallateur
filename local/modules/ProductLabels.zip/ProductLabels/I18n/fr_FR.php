<?php
return array(
    // 'an english string' => 'La traduction française de la chaine',
);
