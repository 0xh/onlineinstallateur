<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginLogConfig as BasePluginLogConfig;

class PluginLogConfig extends BasePluginLogConfig
{

}
