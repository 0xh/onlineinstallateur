<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\EmployeesServices as BaseEmployeesServices;

class EmployeesServices extends BaseEmployeesServices
{

}
