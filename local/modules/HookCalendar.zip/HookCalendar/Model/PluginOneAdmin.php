<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginOneAdmin as BasePluginOneAdmin;

class PluginOneAdmin extends BasePluginOneAdmin
{

}
