<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Options as BaseOptions;

class Options extends BaseOptions
{

}
