<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginInvoiceItems as BasePluginInvoiceItems;

class PluginInvoiceItems extends BasePluginInvoiceItems
{

}
