<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginSms as BasePluginSms;

class PluginSms extends BasePluginSms
{

}
