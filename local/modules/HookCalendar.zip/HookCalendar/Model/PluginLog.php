<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginLog as BasePluginLog;

class PluginLog extends BasePluginLog
{

}
