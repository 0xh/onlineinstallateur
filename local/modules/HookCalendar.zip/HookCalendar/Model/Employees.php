<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Employees as BaseEmployees;

class Employees extends BaseEmployees
{

}
