<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Calendars as BaseCalendars;

class Calendars extends BaseCalendars
{

}
