<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Users as BaseUsers;

class Users extends BaseUsers
{

}
