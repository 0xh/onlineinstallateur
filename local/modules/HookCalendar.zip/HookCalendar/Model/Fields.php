<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Fields as BaseFields;

class Fields extends BaseFields
{

}
