<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginLocale as BasePluginLocale;

class PluginLocale extends BasePluginLocale
{

}
