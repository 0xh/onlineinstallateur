<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginLocaleLanguages as BasePluginLocaleLanguages;

class PluginLocaleLanguages extends BasePluginLocaleLanguages
{

}
