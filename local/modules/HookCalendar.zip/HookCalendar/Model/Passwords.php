<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Passwords as BasePasswords;

class Passwords extends BasePasswords
{

}
