<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\BookingsServices as BaseBookingsServices;

class BookingsServices extends BaseBookingsServices
{

}
