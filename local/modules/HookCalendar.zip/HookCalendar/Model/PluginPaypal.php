<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginPaypal as BasePluginPaypal;

class PluginPaypal extends BasePluginPaypal
{

}
