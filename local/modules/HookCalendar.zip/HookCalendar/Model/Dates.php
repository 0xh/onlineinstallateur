<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Dates as BaseDates;

class Dates extends BaseDates
{

}
