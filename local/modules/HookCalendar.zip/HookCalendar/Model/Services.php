<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Services as BaseServices;

class Services extends BaseServices
{

}
