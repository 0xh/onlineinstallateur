<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Bookings as BaseBookings;

class Bookings extends BaseBookings
{

}
