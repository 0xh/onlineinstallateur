<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginCountry as BasePluginCountry;

class PluginCountry extends BasePluginCountry
{

}
