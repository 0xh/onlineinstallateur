<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\MultiLang as BaseMultiLang;

class MultiLang extends BaseMultiLang
{

}
