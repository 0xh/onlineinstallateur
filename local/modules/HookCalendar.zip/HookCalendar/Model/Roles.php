<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\Roles as BaseRoles;

class Roles extends BaseRoles
{

}
