<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginInvoiceConfig as BasePluginInvoiceConfig;

class PluginInvoiceConfig extends BasePluginInvoiceConfig
{

}
