<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\WorkingTimes as BaseWorkingTimes;

class WorkingTimes extends BaseWorkingTimes
{

}
