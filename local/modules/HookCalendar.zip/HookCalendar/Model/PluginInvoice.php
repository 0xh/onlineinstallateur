<?php

namespace HookCalendar\Model;

use HookCalendar\Model\Base\PluginInvoice as BasePluginInvoice;

class PluginInvoice extends BasePluginInvoice
{

}
