<?php
return array(
    // 'an english string' => 'The displayed english string',
);
